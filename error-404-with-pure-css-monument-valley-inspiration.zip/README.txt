A Pen created at CodePen.io. You can find this one at https://codepen.io/sus-casasola9210/pen/mLREVP.

 I entered the Up Labs Challenge for 404 pages and I made this Monument Valley inspired illustration using only CSS